package bytedance.example.easy_tiktok;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

import bytedance.example.easy_tiktok.databinding.ActivityMainBinding;
import bytedance.example.easy_tiktok.frags.IndividualFragment;
import bytedance.example.easy_tiktok.frags.ListFragment;
import bytedance.example.easy_tiktok.frags.VideoFragment;
import bytedance.example.easy_tiktok.utils.MyFragAdapter;
import bytedance.example.easy_tiktok.vm.MainVm;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding mainBinding;    //���������ļ�
    String[] titles = {"��Ƶ","��","�ҵ�"};
    List<Fragment> fragmentList = new ArrayList<>();
    View view;
    MainVm mainvm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //�󶨲����ļ�
        mainBinding = DataBindingUtil.setContentView(this,R.layout.activity_main);

        mainvm = new ViewModelProvider(this,new ViewModelProvider.NewInstanceFactory()).get(MainVm.class);
        mainBinding.setVm(mainvm);
        mainBinding.setLifecycleOwner(this);

        fragmentList.add(new VideoFragment());
        fragmentList.add(new ListFragment());
        fragmentList.add(new IndividualFragment());

        mainBinding.vp.setAdapter(new MyFragAdapter(getSupportFragmentManager(),fragmentList,titles));
        mainBinding.tablayout.setupWithViewPager(mainBinding.vp);
    }
}
