package bytedance.example.easy_tiktok.frags

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.motion.utils.Oscillator.TAG
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import bytedance.example.easy_tiktok.*
import bytedance.example.easy_tiktok.bean.VideoItem
import bytedance.example.easy_tiktok.utils.Data
import bytedance.example.easy_tiktok.utils.VideoAdapter
import java.io.*
import java.util.*


class PersonalLowFragment : Fragment() {
    private val videoList = ArrayList<VideoItem>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        Log.d("sjk22", "1111")
        val view = inflater.inflate(R.layout.per_low_frag, container, false)
        inits()
        val recyclerView:RecyclerView = view.findViewById(R.id.recyclerView)
        val layoutManager = StaggeredGridLayoutManager(3,
            StaggeredGridLayoutManager.VERTICAL)
        recyclerView.layoutManager = layoutManager
        Log.d("sjk22", "Size :"+videoList.size.toString())
        val adapter = VideoAdapter(videoList)
        recyclerView.adapter = adapter
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }
    private fun inits() {
        for (i in 0 until Data.user.video.size){
            videoList.add(Data.user.video[i])
        }
    }
}