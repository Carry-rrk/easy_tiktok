package bytedance.example.easy_tiktok.frags;

import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import bytedance.example.easy_tiktok.utils.Data
import bytedance.example.easy_tiktok.R
import bytedance.example.easy_tiktok.frags.userinfo_tools
import bytedance.example.easy_tiktok.bean.personal_info

class PersonalUpFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.per_up_frag, container, false)
        val touxiang :ImageView = view.findViewById(R.id.imageView)
        touxiang.setImageBitmap(Data.user.avatar.bitmap)
        val nickname : TextView = view.findViewById(R.id.nickname)
        nickname.text = Data.user.nickname
        return view
    }
}