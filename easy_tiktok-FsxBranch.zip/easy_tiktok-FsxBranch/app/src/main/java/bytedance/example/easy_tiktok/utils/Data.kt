package bytedance.example.easy_tiktok.utils;

import bytedance.example.easy_tiktok.bean.personal_info
import bytedance.example.easy_tiktok.frags.userinfo_tools

object Data {
    private val get_user = userinfo_tools()
    val user : personal_info = get_user._user_info
}