package bytedance.example.easy_tiktok.utils

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import bytedance.example.easy_tiktok.R
import bytedance.example.easy_tiktok.bean.VideoItem

class VideoAdapter(private val videoList: List<VideoItem>) : RecyclerView.Adapter<VideoAdapter.ViewHolder> (){

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val videoImage : ImageView = view.findViewById(R.id.videoImage)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.video_cover, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val videoID : VideoItem= videoList[position]
        holder.videoImage.setImageBitmap(videoID.videoCover)
        Log.d("sjk", "onBindViewHolder")
    }
    override fun getItemCount() = videoList.size
}