package bytedance.example.easy_tiktok.frags

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import bytedance.example.easy_tiktok.*
import bytedance.example.easy_tiktok.utils.Data
import java.util.*

class PersonalMidFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.per_mid_frag, container, false)
        val huozan: TextView = view.findViewById(R.id.huozan)
        huozan.text = Data.user.fans.size.toString()
        val guanzhu: TextView = view.findViewById(R.id.guanzhu)
        guanzhu.text = Data.user.fans.size.toString()
        val fensi : TextView = view.findViewById(R.id.fensi)
        fensi.text = Data.user.fans.size.toString()
        val country : TextView = view.findViewById(R.id.textCountry)
        return view
    }
}