package bytedance.example.easy_tiktok.vm;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MainVm extends ViewModel {

    public MutableLiveData<String> title = new MutableLiveData<>();

}
