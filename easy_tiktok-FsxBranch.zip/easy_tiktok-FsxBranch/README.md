# easy_tiktok
The Fourth Youth Training Camp

/**
    2022.07.23
    by Fsx
*/
This is program template

/**
2022.07.24
by Fsx
*/
Finishing ./utils/MyOkHttp.java,
modify permission 